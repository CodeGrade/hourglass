interface ILoInt { ... }
class MtLoInt implements ILoInt { ... }
class ConsLoInt implements ILoInt {
  int first;
  ILoInt rest;
  ConsLoInt(int first, ILoInt rest) {
    this.first = first;
    this.rest = rest;
  }
}