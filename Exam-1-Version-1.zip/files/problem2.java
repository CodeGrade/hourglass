interface ILoBool { ... }
class MtLoBool implements ILoBool { ... }
class ConsLoBool implements ILoBool {
  boolean first;
  ILoBool rest;
  ConsLoBool(boolean first, ILoBool rest) {
    this.first = first;
    this.rest = rest;
  }
}
class PairOfLists {
  ILoInt left;
  ILoInt right;
  PairOfLists(ILoInt left, ILoInt right) {
    this.left = left;
    this.right = right;
  }
}