~ro:1:s~// Beige-highlighted code is read-only: do not modify it.

// Represents the current volume levels for a stereo track
// NOTE: Neither volume can ever be negative!
class StereoMix {
  int leftVolume;
  int rightVolume;
  StereoMix(~ro:1:e~???~ro:2:s~) {~ro:2:e~
    ???? // FINISH THIS YOURSELF
  ~ro:3:s~}

  StereoMix changeVolume(int changeLeft, int changeRight) {
    return new StereoMix(this.leftVolume + changeLeft,
                         this.rightVolume + changeRight);
  }
}

// An editing action to be taken while mixing an audio track
interface IMixEdit {~ro:3:e~
  ...
~ro:4:s~}
// Increases the left volume and decreases the right volume
class PanLeft implements IMixEdit {
  int shiftLeft;
  PanLeft(int shiftLeft) { this.shiftLeft = shiftLeft; }~ro:4:e~
  ...
~ro:5:s~}
// Increases the volume in both left and right channels
class Swell implements IMixEdit {
  int gain;
  Swell(int gain) { this.gain = gain; }~ro:5:e~
  ...  
~ro:6:s~}
// Decreases the volume in both left and right channels
class Fade implements IMixEdit {
  int loss;
  Fade(int loss) { this.loss = loss; }~ro:6:e~
  ...
~ro:7:s~}

// Represents a sequence of edit steps
interface ILoMixEdit {
  // Applies each edit to the initial stereo mix, in order from
  // first to last, and produces the final stereo mix, if possible
  StereoMix applyTo(StereoMix initial);
}
class MtLoMixEdit implements ILoMixEdit {
  public StereoMix applyTo(StereoMix initial) { return initial; }
}
class ConsLoMixEdit implements ILoMixEdit {
  public StereoMix applyTo(StereoMix initial) {~ro:7:e~
    ??? // FINISH THIS YOURSELF
  ~ro:8:s~}
}~ro:8:e~

// You may add scratch notes or additional code down here, if needed