// Represents the current volume levels for a stereo track
// NOTE: Neither volume can ever be negative!
class StereoMix {
  int leftVolume;
  int rightVolume;
  StereoMix(???) { ???? } // FINISH THIS YOURSELF

  StereoMix changeVolume(int changeLeft, int changeRight) {
    return new StereoMix(this.leftVolume + changeLeft,
                         this.rightVolume + changeRight);
  }
}

// An editing action to be taken while mixing an audio track
interface IMixEdit { ... }
// Increases the left volume and decreases the right volume
class PanLeft implements IMixEdit {
  int shiftLeft;
  PanLeft(int shiftLeft) { this.shiftLeft = shiftLeft; }
}
// Increases the volume in both left and right channels
class Swell implements IMixEdit {
  int gain;
  Swell(int gain) { this.gain = gain; }
}
// Decreases the volume in both left and right channels
class Fade implements IMixEdit {
  int loss;
  Fade(int loss) { this.loss = loss; }
}

// Represents a sequence of edit steps
interface ILoMixEdit {
  // Applies each edit to the initial stereo mix, in order from
  // first to last, and produces the final stereo mix, if possible
  StereoMix applyTo(StereoMix initial);
}
class MtLoMixEdit implements ILoMixEdit {
  public StereoMix applyTo(StereoMix initial) { return initial; }
}
class ConsLoMixEdit implements ILoMixEdit {
  public StereoMix applyTo(StereoMix initial) { ??? }
}