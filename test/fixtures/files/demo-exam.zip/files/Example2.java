~ro:1:s~// This should be locked to the left
// and continues to here
~ro:1:e~class Foo {

~ro:2:s~// This should be locked in the middle~ro:2:e~

~ro:3:s~}~ro:3:e~
